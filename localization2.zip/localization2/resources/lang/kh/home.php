<?php
return[

	'home_menu'=>'ម៉ឺនុយផ្ទះ',
	'about_menu'=>'អំពីម៉ឺនុយ',
	'contact_menu'=>'ម៉ឺនុយទំនាក់ទំនង',
	'message'=>'សារ',
];
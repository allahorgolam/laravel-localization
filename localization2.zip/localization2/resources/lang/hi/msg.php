<?php

return['welcome'=>"সবাইকে স্বাগতম"];
?>
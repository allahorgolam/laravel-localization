<?php
return[

	'home_menu'=>'主菜單',
	'about_menu'=>'關於菜單',
	'contact_menu'=>'聯繫菜單',
	'message'=>'信息e',
];
<?php
return[

	'home_menu'=>'HHome',
	'about_menu'=>'About Us',
	'contact_menu'=>'Contact Us',
	'message'=>'Welcome',
];
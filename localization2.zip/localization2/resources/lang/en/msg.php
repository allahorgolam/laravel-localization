<?php

return['welcome'=>"Welcome Everyone"];
?>
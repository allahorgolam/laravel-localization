<html>

<body>
	<h1>User Login</h1>
	<form action="/login" method="post">
		@csrf
		<input type="text" name="user">
		<input type="password" name="password">
		<button type="submit">Login</button>
	</form>
</body>
</html>
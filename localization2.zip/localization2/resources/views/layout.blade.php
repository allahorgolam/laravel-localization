
<html>
<head>
	
	
	<title>app title - @yield('title')</title>
	<style>
		.sidebar{
			float: right;
			background-color: #3F51B5;
			color: lightblue;
		}
		.main{
			background-color: green;
			color: white;
			height: 133px;
		}

	</style>
</head>
<body>
	<div class="sidebar">

		@section('sidebar')
		@show
		
	</div>
	<div class="main">
		@yield('main')
		
	</div>
	<div class="footer">
		@section('footer')
		@show
		
		
	</div>
</body>
</html>

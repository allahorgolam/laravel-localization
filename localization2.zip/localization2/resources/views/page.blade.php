<h1>
	{{__('msg.welcome')}}


</h1>
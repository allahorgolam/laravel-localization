 @extends('layout')
 @section('title',"Papa Page 2")


@section('sidebar')
  <h1>Main Siebar</h1>
  <h4>some more content with 2nd page</h4>
  <p>some text</p>
@endsection

@section('main',"main content")


@section('footer')
  <h1>another page footer</h1>
  
@endsection


<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class Youtube extends Controller
{
    //
    function index()
    {
    	return User::all();
    }
}

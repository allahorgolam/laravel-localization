 
 <?php $__env->startSection('title',"Papa Page 2"); ?>


<?php $__env->startSection('sidebar'); ?>
  <h1>Main Siebar</h1>
  <h4>some more content with 2nd page</h4>
  <p>some text</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main',"main content"); ?>


<?php $__env->startSection('footer'); ?>
  <h1>another page footer</h1>
  
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL\resources\views/page2.blade.php ENDPATH**/ ?>
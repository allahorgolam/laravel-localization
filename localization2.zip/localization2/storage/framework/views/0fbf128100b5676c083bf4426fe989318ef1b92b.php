<html>

<body>
	<h1>User Login</h1>
	<form action="/login" method="post">
		<?php echo csrf_field(); ?>
		<input type="text" name="user">
		<input type="password" name="password">
		<button type="submit">Login</button>
	</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\LARAVEL\resources\views/login.blade.php ENDPATH**/ ?>
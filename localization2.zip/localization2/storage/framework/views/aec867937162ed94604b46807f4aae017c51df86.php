<h1>
	<?php echo e(__('msg.welcome')); ?>



</h1><?php /**PATH C:\xampp\htdocs\LARAVEL\resources\views/page.blade.php ENDPATH**/ ?>

<html>
<head>
	
	
	<title>app title - <?php echo $__env->yieldContent('title'); ?></title>
	<style>
		.sidebar{
			float: right;
			background-color: #3F51B5;
			color: lightblue;
		}
		.main{
			background-color: green;
			color: white;
			height: 133px;
		}

	</style>
</head>
<body>
	<div class="sidebar">

		<?php $__env->startSection('sidebar'); ?>
		<?php echo $__env->yieldSection(); ?>
		
	</div>
	<div class="main">
		<?php echo $__env->yieldContent('main'); ?>
		
	</div>
	<div class="footer">
		<?php $__env->startSection('footer'); ?>
		<?php echo $__env->yieldSection(); ?>
		
		
	</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\LARAVEL\resources\views/layout.blade.php ENDPATH**/ ?>